package com.example.test;

import android.content.Context;
import android.os.AsyncTask;

import androidx.annotation.NonNull;
import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import androidx.sqlite.db.SupportSQLiteDatabase;

import java.util.List;

@Database(entities = {Enemy.class}, version = 1)
public abstract class EnemyDatabase extends RoomDatabase {

    private static EnemyDatabase instance;

    public abstract EnemyDao enemyDao();

    public static synchronized EnemyDatabase getInstance(Context context) {
        if(instance == null) {
            instance = Room.databaseBuilder(context.getApplicationContext(),
                    EnemyDatabase.class, "enemy")
                    .fallbackToDestructiveMigration()
                    .addCallback(roomCallback)
                    .build();
            SupportSQLiteDatabase db = instance.getOpenHelper().getWritableDatabase();
        }
        return instance;
    }

    private static Callback roomCallback = new Callback() {
        @Override
        public void onCreate(@NonNull SupportSQLiteDatabase db) {
            super.onCreate(db);
            new PopulateDbAsyncTask(instance).execute();
        }
    };

    private static class PopulateDbAsyncTask extends AsyncTask<Void, Void, Void> {
        private EnemyDao enemyDao;

        private PopulateDbAsyncTask(EnemyDatabase db) {
            enemyDao = db.enemyDao();
        }

        @Override
        protected Void doInBackground(Void... voids) {
            enemyDao.insert(new Enemy(1, 175, "yourbasic"));
            enemyDao.insert(new Enemy(2, 175, "yourtank"));
            enemyDao.insert(new Enemy(3, 175, "yourbattle"));
            enemyDao.insert(new Enemy(4, 175, "yourmass"));
            enemyDao.insert(new Enemy(5, 175, "yourbasic"));
            enemyDao.insert(new Enemy(5, 174, "yourtank"));
            enemyDao.insert(new Enemy(6, 175, "yourbasic"));
            enemyDao.insert(new Enemy(6, 170, "yourbasic"));
            enemyDao.insert(new Enemy(6, 165, "yourbasic"));
            enemyDao.insert(new Enemy(6, 160, "yourbasic"));
            enemyDao.insert(new Enemy(7, 175, "yourbasic"));
            enemyDao.insert(new Enemy(7, 174, "yourtank"));
            enemyDao.insert(new Enemy(7, 170, "yourbasic"));
            enemyDao.insert(new Enemy(7, 169, "yourtank"));
            enemyDao.insert(new Enemy(7, 165, "yourbasic"));
            enemyDao.insert(new Enemy(7, 164, "yourtank"));
            enemyDao.insert(new Enemy(7, 160, "yourbasic"));
            enemyDao.insert(new Enemy(7, 159, "yourtank"));
            enemyDao.insert(new Enemy(8, 175, "yourbasic"));
            enemyDao.insert(new Enemy(8, 173, "yourbasic"));
            enemyDao.insert(new Enemy(8, 171, "yourbasic"));
            enemyDao.insert(new Enemy(8, 169, "yourbasic"));
            enemyDao.insert(new Enemy(8, 167, "yourbasic"));
            enemyDao.insert(new Enemy(8, 166, "yourtank"));
            enemyDao.insert(new Enemy(8, 165, "yourbasic"));
            enemyDao.insert(new Enemy(9, 175, "yourbasic"));
            enemyDao.insert(new Enemy(9, 174, "yourtank"));
            enemyDao.insert(new Enemy(9, 173, "yourbasic"));
            enemyDao.insert(new Enemy(9, 171, "yourbasic"));
            enemyDao.insert(new Enemy(9, 170, "yourtank"));
            enemyDao.insert(new Enemy(9, 169, "yourbasic"));
            enemyDao.insert(new Enemy(9, 167, "yourbasic"));
            enemyDao.insert(new Enemy(9, 166, "yourtank"));
            enemyDao.insert(new Enemy(9, 165, "yourbasic"));
            enemyDao.insert(new Enemy(10, 175, "yourbasic"));
            enemyDao.insert(new Enemy(10, 174, "yourtank"));
            enemyDao.insert(new Enemy(10, 173, "yourbasic"));
            enemyDao.insert(new Enemy(10, 171, "yourbasic"));
            enemyDao.insert(new Enemy(10, 170, "yourtank"));
            enemyDao.insert(new Enemy(10, 169, "yourbasic"));
            enemyDao.insert(new Enemy(10, 167, "yourbasic"));
            enemyDao.insert(new Enemy(10, 166, "yourtank"));
            enemyDao.insert(new Enemy(10, 165, "yourbasic"));
            enemyDao.insert(new Enemy(11, 175, "yourbasic"));
            enemyDao.insert(new Enemy(12, 175, "yourtank"));
            enemyDao.insert(new Enemy(13, 175, "yourbattle"));
            enemyDao.insert(new Enemy(14, 175, "yourmass"));
            enemyDao.insert(new Enemy(15, 175, "yourbasic"));
            enemyDao.insert(new Enemy(15, 174, "yourtank"));
            enemyDao.insert(new Enemy(16, 175, "yourbasic"));
            enemyDao.insert(new Enemy(16, 170, "yourbasic"));
            enemyDao.insert(new Enemy(16, 165, "yourbasic"));
            enemyDao.insert(new Enemy(16, 160, "yourbasic"));
            enemyDao.insert(new Enemy(17, 175, "yourbasic"));
            enemyDao.insert(new Enemy(17, 174, "yourtank"));
            enemyDao.insert(new Enemy(17, 170, "yourbasic"));
            enemyDao.insert(new Enemy(17, 169, "yourtank"));
            enemyDao.insert(new Enemy(17, 165, "yourbasic"));
            enemyDao.insert(new Enemy(17, 164, "yourtank"));
            enemyDao.insert(new Enemy(17, 160, "yourbasic"));
            enemyDao.insert(new Enemy(17, 159, "yourtank"));
            enemyDao.insert(new Enemy(18, 175, "yourbasic"));
            enemyDao.insert(new Enemy(18, 173, "yourbasic"));
            enemyDao.insert(new Enemy(18, 171, "yourbasic"));
            enemyDao.insert(new Enemy(18, 169, "yourbasic"));
            enemyDao.insert(new Enemy(18, 167, "yourbasic"));
            enemyDao.insert(new Enemy(18, 166, "yourtank"));
            enemyDao.insert(new Enemy(18, 165, "yourbasic"));
            enemyDao.insert(new Enemy(19, 175, "yourbasic"));
            enemyDao.insert(new Enemy(19, 174, "yourtank"));
            enemyDao.insert(new Enemy(19, 173, "yourbasic"));
            enemyDao.insert(new Enemy(19, 171, "yourbasic"));
            enemyDao.insert(new Enemy(19, 170, "yourtank"));
            enemyDao.insert(new Enemy(19, 169, "yourbasic"));
            enemyDao.insert(new Enemy(19, 167, "yourbasic"));
            enemyDao.insert(new Enemy(19, 166, "yourtank"));
            enemyDao.insert(new Enemy(19, 165, "yourbasic"));
            enemyDao.insert(new Enemy(20, 175, "yourbasic"));
            enemyDao.insert(new Enemy(20, 174, "yourtank"));
            enemyDao.insert(new Enemy(20, 173, "yourbasic"));
            enemyDao.insert(new Enemy(20, 171, "yourbasic"));
            enemyDao.insert(new Enemy(20, 170, "yourtank"));
            enemyDao.insert(new Enemy(20, 169, "yourbasic"));
            enemyDao.insert(new Enemy(20, 167, "yourbasic"));
            enemyDao.insert(new Enemy(20, 166, "yourtank"));
            enemyDao.insert(new Enemy(20, 165, "yourbasic"));
            enemyDao.insert(new Enemy(21, 175, "yourbasic"));
            enemyDao.insert(new Enemy(22, 175, "yourtank"));
            enemyDao.insert(new Enemy(23, 175, "yourbattle"));
            enemyDao.insert(new Enemy(24, 175, "yourmass"));
            enemyDao.insert(new Enemy(25, 175, "yourbasic"));
            enemyDao.insert(new Enemy(25, 174, "yourtank"));
            enemyDao.insert(new Enemy(26, 175, "yourbasic"));
            enemyDao.insert(new Enemy(26, 170, "yourbasic"));
            enemyDao.insert(new Enemy(26, 165, "yourbasic"));
            enemyDao.insert(new Enemy(26, 160, "yourbasic"));
            enemyDao.insert(new Enemy(27, 175, "yourbasic"));
            enemyDao.insert(new Enemy(27, 174, "yourtank"));
            enemyDao.insert(new Enemy(27, 170, "yourbasic"));
            enemyDao.insert(new Enemy(27, 169, "yourtank"));
            enemyDao.insert(new Enemy(27, 165, "yourbasic"));
            enemyDao.insert(new Enemy(27, 164, "yourtank"));
            enemyDao.insert(new Enemy(27, 160, "yourbasic"));
            enemyDao.insert(new Enemy(27, 159, "yourtank"));
            enemyDao.insert(new Enemy(28, 175, "yourbasic"));
            enemyDao.insert(new Enemy(28, 173, "yourbasic"));
            enemyDao.insert(new Enemy(28, 171, "yourbasic"));
            enemyDao.insert(new Enemy(28, 169, "yourbasic"));
            enemyDao.insert(new Enemy(28, 167, "yourbasic"));
            enemyDao.insert(new Enemy(28, 166, "yourtank"));
            enemyDao.insert(new Enemy(28, 165, "yourbasic"));
            enemyDao.insert(new Enemy(29, 175, "yourbasic"));
            enemyDao.insert(new Enemy(29, 174, "yourtank"));
            enemyDao.insert(new Enemy(29, 173, "yourbasic"));
            enemyDao.insert(new Enemy(29, 171, "yourbasic"));
            enemyDao.insert(new Enemy(29, 170, "yourtank"));
            enemyDao.insert(new Enemy(29, 169, "yourbasic"));
            enemyDao.insert(new Enemy(29, 167, "yourbasic"));
            enemyDao.insert(new Enemy(29, 166, "yourtank"));
            enemyDao.insert(new Enemy(29, 165, "yourbasic"));
            enemyDao.insert(new Enemy(30, 175, "yourbasic"));
            enemyDao.insert(new Enemy(30, 174, "yourtank"));
            enemyDao.insert(new Enemy(30, 173, "yourbasic"));
            enemyDao.insert(new Enemy(30, 171, "yourbasic"));
            enemyDao.insert(new Enemy(30, 170, "yourtank"));
            enemyDao.insert(new Enemy(30, 169, "yourbasic"));
            enemyDao.insert(new Enemy(30, 167, "yourbasic"));
            enemyDao.insert(new Enemy(30, 166, "yourtank"));
            enemyDao.insert(new Enemy(30, 165, "yourbasic"));
            return null;
        }
    }
}
