package com.example.test;

import static java.lang.Thread.sleep;

import android.app.Application;
import android.os.AsyncTask;
import android.os.Build;

import androidx.annotation.RequiresApi;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.fasterxml.jackson.databind.ObjectMapper;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class MonsterViewModel extends ViewModel {
    // CRUD
    private MonsterRepository monsterRepository;
    private EnemyRepository enemyRepository;
    private PlayerRepository playerRepository;
    private FunctionRepository functionRepository;

    // Create a LiveData
    private MutableLiveData<Monster> ourNewMonster = null;
    private MutableLiveData<Monster> yourNewMonster = null;
    private MutableLiveData<List<Enemy>> enemies = null;
    private MutableLiveData<Integer> money = null;
    private MutableLiveData<Map<String, Integer>> totalMap = null;
    private MutableLiveData<List<Monster>> haveMonsters = null;
    private MutableLiveData<Monster> updatedMonster = null;

    public MutableLiveData<Monster> getOurNewMonster() {
        if (ourNewMonster == null) {
            ourNewMonster = new MutableLiveData<Monster>();
        }
        return ourNewMonster;
    }

    public MutableLiveData<Monster> getYourNewMonster() {
        if (yourNewMonster == null) {
            yourNewMonster = new MutableLiveData<Monster>();
        }
        return yourNewMonster;
    }

    public MutableLiveData<List<Enemy>> getEnemies() {
        if (enemies == null) {
            enemies = new MutableLiveData<List<Enemy>>();
        }
        return enemies;
    }

    public MutableLiveData<Integer> getMoney() {
        if (money == null) {
            money = new MutableLiveData<Integer>();
        }
        return money;
    }

    public MutableLiveData<Map<String, Integer>> getTotalMap() {
        if(totalMap == null) {
            totalMap = new MutableLiveData<Map<String, Integer>>();
        }
        return totalMap;
    }

    public MutableLiveData<List<Monster>> getHaveMonsters() {
        if(haveMonsters == null) {
            haveMonsters = new MutableLiveData<List<Monster>>();
        }
        return haveMonsters;
    }

    public MutableLiveData<Monster> getUpdatedMonster() {
        if(updatedMonster == null) {
            updatedMonster = new MutableLiveData<Monster>();
        }
        return updatedMonster;
    }

    @RequiresApi(api = Build.VERSION_CODES.N)
    public synchronized void addOurNewMonster(String name) {
        ourNewMonster.postValue(monsterRepository.findMonsterByName(name));
    }

    @RequiresApi(api = Build.VERSION_CODES.N)
    public synchronized void addYourNewMonster(int mapNumber, String name) {
        int multiply = (mapNumber - 1) / 10;
        multiply++;
        Monster enemy = monsterRepository.findMonsterByName(name);
        enemy.setTotal_hp(enemy.getTotal_hp() * multiply);
        enemy.setHp(enemy.getTotal_hp());
        enemy.setAttack(enemy.getAttack() * multiply);
        yourNewMonster.postValue(enemy);
    }

    @RequiresApi(api = Build.VERSION_CODES.N)
    public Monster findMonsterByName(String name) {
        return monsterRepository.findMonsterByName(name);
    }

    @RequiresApi(api = Build.VERSION_CODES.N)
    public void getEnemiesByMapNumber(int mapNumber) {
        enemies.postValue(enemyRepository.findEnemyByMapNumber(mapNumber));
    }

    public List<Enemy> getAllEnemies() {
        return enemyRepository.getAllEnemies();
    }

    public List<Monster> getAllMonsters() {
        return monsterRepository.getAllMonsters();
    }

    public List<Player> getAllPlayer() {
        return playerRepository.getAllPlayer();
    }

    public List<Function> getAllFunctions() {
        return functionRepository.getAllFunctions();
    }

    @RequiresApi(api = Build.VERSION_CODES.N)
    public void clear(String name, int mapNumber) {
        playerRepository.clear(name, mapNumber);
    }

    public void setMoney(String name) {
        money.postValue(playerRepository.getPlayer(name).getMoney());
    }

    public void setMapTotalNumber(String name) {
        totalMap.postValue(playerRepository.returnMap(name));
    }

    @RequiresApi(api = Build.VERSION_CODES.N)
    public void setHaveMonsters() {
        haveMonsters.postValue(monsterRepository.getAllMonsters().stream().filter(e -> e.isHave()).collect(Collectors.toList()));
    }

    @RequiresApi(api = Build.VERSION_CODES.N)
    public void upgrade(String monsterName, String userName) throws customedException{
        Monster target = monsterRepository.findMonsterByName(monsterName);
        Player player = playerRepository.getPlayer(userName);
        int cost = target.isCastle()? 50 : target.getCost();
        if(player.getMoney() < cost * (target.getUpgradeCount() + 1)) {
            throw new customedException("업그레이드 비용이 부족합니다.");
        }
        else if(target.getUpgradeCount() == 10) {
            throw new customedException("더 이상 업그레이드할 수 없습니다.");
        }
        else {
            player.setMoney(player.getMoney() - cost * (target.getUpgradeCount() + 1));
            playerRepository.update(player);
            money.postValue(player.getMoney());
            double before = 1 + 0.1*target.getUpgradeCount();
            double next = 1 + 0.1*(target.getUpgradeCount() + 1);
            target.setAttack((int) Math.round(target.getAttack() / before * next));
            target.setTotal_hp((int) Math.round(target.getTotal_hp() / before * next));
            target.setUpgradeCount(target.getUpgradeCount() + 1);
            monsterRepository.update(target);
            updatedMonster.postValue(target);
        }
    }

    public MonsterViewModel(@androidx.annotation.NonNull Application application) {
        super();
        monsterRepository = new MonsterRepository(application);
        enemyRepository = new EnemyRepository(application);
        playerRepository = new PlayerRepository(application);
        functionRepository = new FunctionRepository(application);
    }

    public void monsterInsert(Monster monster) {
        monsterRepository.insert(monster);
    }

    public void monsterUpdate(Monster monster) {
        monsterRepository.update(monster);
    }

    public void monsterDelete(Monster monster) {
        monsterRepository.delete(monster);
    }

    public void enemyInsert(Enemy enemy) { enemyRepository.insert(enemy);    }

    public void enemyUpdate(Enemy enemy) {
        enemyRepository.update(enemy);
    }

    public void enemyDelete(Enemy enemy) {
        enemyRepository.delete(enemy);
    }
}
